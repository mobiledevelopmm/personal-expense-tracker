import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../models/transaction.dart';

class TransactionService {
  final FirebaseFirestore _firestore;
  final FirebaseAuth _auth;

  TransactionService({
    FirebaseFirestore? firestore,
    FirebaseAuth? auth,
  })  : _firestore = firestore ?? FirebaseFirestore.instance,
        _auth = auth ?? FirebaseAuth.instance;

  CollectionReference<Map<String, dynamic>> _userTransactions() {
    final user = _auth.currentUser;

    if (user == null) {
      throw StateError('Please log in to access transactions.');
    }

    return _firestore
        .collection('users')
        .doc(user.uid)
        .collection('transactions');
  }

  Stream<List<ExpenseTransaction>> watchTransactions() {
    return _userTransactions()
        .orderBy('date', descending: true)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
          .map(
            (doc) => ExpenseTransaction.fromMap(
          doc.id,
          doc.data(),
        ),
      )
          .toList(),
    );
  }

  Future<void> addTransaction(ExpenseTransaction transaction) async {
    await _userTransactions().add(transaction.toMap());
  }

  Future<void> deleteTransaction(String id) async {
    await _userTransactions().doc(id).delete();
  }
}